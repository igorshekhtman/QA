var stats = {
    type: "GROUP",
contents: {
"login-99dea78007133396a7b8ed70578ac6ae": {
        type: "GROUP",
contents: {
"login-page-024588fa3c938f335a36fec9f17624f4": {
        type: "REQUEST",
        name: "Login page",
path: "Login / Login page",
pathFormatted: "login---login-page-ec10d26222d452283ad31786b6c7417a",
stats: {
    "name": "Login page",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "17",
        "ok": "17",
        "ko": "-"
    },
    "percentiles1": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "percentiles2": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 30,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"submit-login-f643596223977882be93e2205ad5e14d": {
        type: "REQUEST",
        name: "Submit login",
path: "Login / Submit login",
pathFormatted: "login---submit-login-1ecb60c3635236b2aea1825075ac3913",
stats: {
    "name": "Submit login",
    "numberOfRequests": {
        "total": "30",
        "ok": "28",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "50",
        "ok": "320",
        "ko": "50"
    },
    "maxResponseTime": {
        "total": "1190",
        "ok": "440",
        "ko": "1190"
    },
    "meanResponseTime": {
        "total": "369",
        "ok": "351",
        "ko": "620"
    },
    "standardDeviation": {
        "total": "164",
        "ok": "32",
        "ko": "570"
    },
    "percentiles1": {
        "total": "440",
        "ok": "390",
        "ko": "1190"
    },
    "percentiles2": {
        "total": "1190",
        "ok": "440",
        "ko": "1190"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 28,
        "percentage": 93
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    }
},
name: "Login",
path: "Login",
pathFormatted: "login-99dea78007133396a7b8ed70578ac6ae",
stats: {
    "name": "Login",
    "numberOfRequests": {
        "total": "30",
        "ok": "28",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "12100",
        "ok": "12400",
        "ko": "12100"
    },
    "maxResponseTime": {
        "total": "13250",
        "ok": "12550",
        "ko": "13250"
    },
    "meanResponseTime": {
        "total": "12457",
        "ok": "12442",
        "ko": "12675"
    },
    "standardDeviation": {
        "total": "187",
        "ok": "0",
        "ko": "575"
    },
    "percentiles1": {
        "total": "12550",
        "ok": "12500",
        "ko": "13250"
    },
    "percentiles2": {
        "total": "13250",
        "ok": "12550",
        "ko": "13250"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 28,
        "percentage": 93
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"token-459a6f79ad9b13cbcb5f692d2cc7a94d": {
        type: "GROUP",
contents: {
"token-exchange-ce37265b594ed58a9857bdf00c769ea8": {
        type: "REQUEST",
        name: "Token exchange",
path: "Token / Token exchange",
pathFormatted: "token---token-exchange-f1298f80173ae42f1d4d7533dae4b717",
stats: {
    "name": "Token exchange",
    "numberOfRequests": {
        "total": "28",
        "ok": "28",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "53",
        "ok": "53",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "percentiles1": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "percentiles2": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 28,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Token",
path: "Token",
pathFormatted: "token-459a6f79ad9b13cbcb5f692d2cc7a94d",
stats: {
    "name": "Token",
    "numberOfRequests": {
        "total": "30",
        "ok": "28",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "40",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "150",
        "ok": "150",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "53",
        "ok": "57",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "30",
        "ok": "27",
        "ko": "0"
    },
    "percentiles1": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "percentiles2": {
        "total": "150",
        "ok": "150",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 28,
        "percentage": 93
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"patient-01122a97dca927210827560cb7d76af8": {
        type: "GROUP",
contents: {
"patient-demographics-20fa1e3af35ff968fdfaff3f17f2132f": {
        type: "REQUEST",
        name: "Patient demographics",
path: "Patient / Patient demographics",
pathFormatted: "patient---patient-demographics-7381f0c739ca78ed2209e34f68b4acce",
stats: {
    "name": "Patient demographics",
    "numberOfRequests": {
        "total": "28",
        "ok": "28",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23850",
        "ok": "23850",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1576",
        "ok": "1576",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4310",
        "ok": "4310",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1680",
        "ok": "1680",
        "ko": "-"
    },
    "percentiles2": {
        "total": "23850",
        "ok": "23850",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 16,
        "percentage": 57
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 6,
        "percentage": 21
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 6,
        "percentage": 21
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Patient",
path: "Patient",
pathFormatted: "patient-01122a97dca927210827560cb7d76af8",
stats: {
    "name": "Patient",
    "numberOfRequests": {
        "total": "30",
        "ok": "28",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "6000",
        "ok": "6140",
        "ko": "6000"
    },
    "maxResponseTime": {
        "total": "29860",
        "ok": "29860",
        "ko": "6050"
    },
    "meanResponseTime": {
        "total": "7470",
        "ok": "7574",
        "ko": "6025"
    },
    "standardDeviation": {
        "total": "4184",
        "ok": "4311",
        "ko": "25"
    },
    "percentiles1": {
        "total": "7660",
        "ok": "7660",
        "ko": "6050"
    },
    "percentiles2": {
        "total": "29860",
        "ok": "29860",
        "ko": "6050"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 28,
        "percentage": 93
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"document-0945359809dad1fbf3dea1c95a0da951": {
        type: "GROUP",
contents: {
"document-retrieval-text-2540ae29a705cec5500c042a139829fe": {
        type: "REQUEST",
        name: "Document retrieval text",
path: "Document / Document retrieval text",
pathFormatted: "document---document-retrieval-text-e01f7dcbbf40fdfec1dd23b9433c370c",
stats: {
    "name": "Document retrieval text",
    "numberOfRequests": {
        "total": "28",
        "ok": "28",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "600",
        "ok": "600",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4130",
        "ok": "4130",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1738",
        "ok": "1738",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "920",
        "ok": "920",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3580",
        "ok": "3580",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4130",
        "ok": "4130",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 4,
        "percentage": 14
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 6,
        "percentage": 21
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 18,
        "percentage": 64
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"document-retrieval-metadata-930bb3ede50d721fd1a8e5b90ab1f422": {
        type: "REQUEST",
        name: "Document retrieval metadata",
path: "Document / Document retrieval metadata",
pathFormatted: "document---document-retrieval-metadata-592e662b974e9b216c65b391aacfd4d5",
stats: {
    "name": "Document retrieval metadata",
    "numberOfRequests": {
        "total": "28",
        "ok": "28",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "32280",
        "ok": "32280",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1321",
        "ok": "1321",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5959",
        "ok": "5959",
        "ko": "-"
    },
    "percentiles1": {
        "total": "510",
        "ok": "510",
        "ko": "-"
    },
    "percentiles2": {
        "total": "32280",
        "ok": "32280",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 27,
        "percentage": 96
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 3
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"document-retrieval-file-a199cf6c05a32d74b4392503ab8249fa": {
        type: "REQUEST",
        name: "Document retrieval file",
path: "Document / Document retrieval file",
pathFormatted: "document---document-retrieval-file-97948b241a7ce3b43fdc9088747c6a5b",
stats: {
    "name": "Document retrieval file",
    "numberOfRequests": {
        "total": "28",
        "ok": "27",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "190",
        "ko": "40"
    },
    "maxResponseTime": {
        "total": "710",
        "ok": "710",
        "ko": "40"
    },
    "meanResponseTime": {
        "total": "387",
        "ok": "400",
        "ko": "40"
    },
    "standardDeviation": {
        "total": "169",
        "ok": "158",
        "ko": "0"
    },
    "percentiles1": {
        "total": "680",
        "ok": "680",
        "ko": "40"
    },
    "percentiles2": {
        "total": "710",
        "ok": "710",
        "ko": "40"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 27,
        "percentage": 96
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 1,
        "percentage": 3
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    }
},
name: "Document",
path: "Document",
pathFormatted: "document-0945359809dad1fbf3dea1c95a0da951",
stats: {
    "name": "Document",
    "numberOfRequests": {
        "total": "30",
        "ok": "27",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "6000",
        "ok": "6850",
        "ko": "6000"
    },
    "maxResponseTime": {
        "total": "41900",
        "ok": "11050",
        "ko": "41900"
    },
    "meanResponseTime": {
        "total": "9217",
        "ok": "8243",
        "ko": "17983"
    },
    "standardDeviation": {
        "total": "6171",
        "ok": "1024",
        "ko": "16912"
    },
    "percentiles1": {
        "total": "11050",
        "ok": "9900",
        "ko": "41900"
    },
    "percentiles2": {
        "total": "41900",
        "ok": "11050",
        "ko": "41900"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 27,
        "percentage": 90
    },
    "group4": {
        "name": "failed",
        "count": 3,
        "percentage": 10
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    }
},
name: "Global Information",
path: "",
pathFormatted: "missing-name-b06d1db11321396efb70c5c483b11923",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "200",
        "ok": "197",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "40"
    },
    "maxResponseTime": {
        "total": "32280",
        "ok": "32280",
        "ko": "1190"
    },
    "meanResponseTime": {
        "total": "775",
        "ok": "780",
        "ko": "427"
    },
    "standardDeviation": {
        "total": "2856",
        "ok": "2876",
        "ko": "540"
    },
    "percentiles1": {
        "total": "2220",
        "ok": "2220",
        "ko": "1190"
    },
    "percentiles2": {
        "total": "4130",
        "ok": "4130",
        "ko": "1190"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 160,
        "percentage": 80
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 12,
        "percentage": 6
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 25,
        "percentage": 12
    },
    "group4": {
        "name": "failed",
        "count": 3,
        "percentage": 1
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
