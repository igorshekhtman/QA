var stats = {
    type: "GROUP",
contents: {
"login-99dea78007133396a7b8ed70578ac6ae": {
        type: "GROUP",
contents: {
"login-page-024588fa3c938f335a36fec9f17624f4": {
        type: "REQUEST",
        name: "Login page",
path: "Login / Login page",
pathFormatted: "login---login-page-ec10d26222d452283ad31786b6c7417a",
stats: {
    "name": "Login page",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "29",
        "ok": "29",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles1": {
        "total": "50",
        "ok": "50",
        "ko": "-"
    },
    "percentiles2": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 30,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"submit-login-f643596223977882be93e2205ad5e14d": {
        type: "REQUEST",
        name: "Submit login",
path: "Login / Submit login",
pathFormatted: "login---submit-login-1ecb60c3635236b2aea1825075ac3913",
stats: {
    "name": "Submit login",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "290",
        "ok": "290",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "420",
        "ok": "420",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "334",
        "ok": "334",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "percentiles1": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "percentiles2": {
        "total": "420",
        "ok": "420",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 30,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Login",
path: "Login",
pathFormatted: "login-99dea78007133396a7b8ed70578ac6ae",
stats: {
    "name": "Login",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "12350",
        "ok": "12350",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "12500",
        "ok": "12500",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12381",
        "ok": "12381",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "12470",
        "ok": "12470",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12500",
        "ok": "12500",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 30,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}

    },"token-459a6f79ad9b13cbcb5f692d2cc7a94d": {
        type: "GROUP",
contents: {
"token-exchange-ce37265b594ed58a9857bdf00c769ea8": {
        type: "REQUEST",
        name: "Token exchange",
path: "Token / Token exchange",
pathFormatted: "token---token-exchange-f1298f80173ae42f1d4d7533dae4b717",
stats: {
    "name": "Token exchange",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "30",
        "ok": "30",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "52",
        "ok": "52",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "19",
        "ok": "19",
        "ko": "-"
    },
    "percentiles1": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "percentiles2": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 30,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Token",
path: "Token",
pathFormatted: "token-459a6f79ad9b13cbcb5f692d2cc7a94d",
stats: {
    "name": "Token",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "54",
        "ok": "54",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "percentiles1": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "percentiles2": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 30,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}

    },"patient-01122a97dca927210827560cb7d76af8": {
        type: "GROUP",
contents: {
"patient-demographics-20fa1e3af35ff968fdfaff3f17f2132f": {
        type: "REQUEST",
        name: "Patient demographics",
path: "Patient / Patient demographics",
pathFormatted: "patient---patient-demographics-7381f0c739ca78ed2209e34f68b4acce",
stats: {
    "name": "Patient demographics",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "120",
        "ok": "120",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "263",
        "ok": "263",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "173",
        "ok": "173",
        "ko": "-"
    },
    "percentiles1": {
        "total": "760",
        "ok": "760",
        "ko": "-"
    },
    "percentiles2": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 29,
        "percentage": 96
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Patient",
path: "Patient",
pathFormatted: "patient-01122a97dca927210827560cb7d76af8",
stats: {
    "name": "Patient",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6110",
        "ok": "6110",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6860",
        "ok": "6860",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6274",
        "ok": "6274",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "174",
        "ok": "174",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6760",
        "ok": "6760",
        "ko": "-"
    },
    "percentiles2": {
        "total": "6860",
        "ok": "6860",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 30,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}

    },"document-0945359809dad1fbf3dea1c95a0da951": {
        type: "GROUP",
contents: {
"document-retrieval-text-2540ae29a705cec5500c042a139829fe": {
        type: "REQUEST",
        name: "Document retrieval text",
path: "Document / Document retrieval text",
pathFormatted: "document---document-retrieval-text-e01f7dcbbf40fdfec1dd23b9433c370c",
stats: {
    "name": "Document retrieval text",
    "numberOfRequests": {
        "total": "30",
        "ok": "28",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "50",
        "ok": "240",
        "ko": "50"
    },
    "maxResponseTime": {
        "total": "3370",
        "ok": "3370",
        "ko": "100"
    },
    "meanResponseTime": {
        "total": "1154",
        "ok": "1231",
        "ko": "75"
    },
    "standardDeviation": {
        "total": "829",
        "ok": "805",
        "ko": "25"
    },
    "percentiles1": {
        "total": "2800",
        "ok": "2800",
        "ko": "100"
    },
    "percentiles2": {
        "total": "3370",
        "ok": "3370",
        "ko": "100"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 10,
        "percentage": 33
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 7,
        "percentage": 23
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 11,
        "percentage": 36
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    },"document-retrieval-metadata-930bb3ede50d721fd1a8e5b90ab1f422": {
        type: "REQUEST",
        name: "Document retrieval metadata",
path: "Document / Document retrieval metadata",
pathFormatted: "document---document-retrieval-metadata-592e662b974e9b216c65b391aacfd4d5",
stats: {
    "name": "Document retrieval metadata",
    "numberOfRequests": {
        "total": "30",
        "ok": "29",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "30",
        "ok": "60",
        "ko": "30"
    },
    "maxResponseTime": {
        "total": "440",
        "ok": "440",
        "ko": "30"
    },
    "meanResponseTime": {
        "total": "153",
        "ok": "157",
        "ko": "30"
    },
    "standardDeviation": {
        "total": "97",
        "ok": "96",
        "ko": "0"
    },
    "percentiles1": {
        "total": "350",
        "ok": "350",
        "ko": "30"
    },
    "percentiles2": {
        "total": "440",
        "ok": "440",
        "ko": "30"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 29,
        "percentage": 96
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 1,
        "percentage": 3
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    },"document-retrieval-file-a199cf6c05a32d74b4392503ab8249fa": {
        type: "REQUEST",
        name: "Document retrieval file",
path: "Document / Document retrieval file",
pathFormatted: "document---document-retrieval-file-97948b241a7ce3b43fdc9088747c6a5b",
stats: {
    "name": "Document retrieval file",
    "numberOfRequests": {
        "total": "30",
        "ok": "29",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "30",
        "ok": "160",
        "ko": "30"
    },
    "maxResponseTime": {
        "total": "930",
        "ok": "930",
        "ko": "30"
    },
    "meanResponseTime": {
        "total": "359",
        "ok": "371",
        "ko": "30"
    },
    "standardDeviation": {
        "total": "187",
        "ok": "179",
        "ko": "0"
    },
    "percentiles1": {
        "total": "620",
        "ok": "620",
        "ko": "30"
    },
    "percentiles2": {
        "total": "930",
        "ok": "930",
        "ko": "30"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 28,
        "percentage": 93
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 1,
        "percentage": 3
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    }
},
name: "Document",
path: "Document",
pathFormatted: "document-0945359809dad1fbf3dea1c95a0da951",
stats: {
    "name": "Document",
    "numberOfRequests": {
        "total": "30",
        "ok": "28",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "6100",
        "ok": "6500",
        "ko": "6100"
    },
    "maxResponseTime": {
        "total": "10350",
        "ok": "10350",
        "ko": "6350"
    },
    "meanResponseTime": {
        "total": "7667",
        "ok": "7770",
        "ko": "6225"
    },
    "standardDeviation": {
        "total": "1038",
        "ok": "997",
        "ko": "125"
    },
    "percentiles1": {
        "total": "9600",
        "ok": "9600",
        "ko": "6350"
    },
    "percentiles2": {
        "total": "10350",
        "ok": "10350",
        "ko": "6350"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 28,
        "percentage": 93
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    }
},
name: "Global Information",
path: "",
pathFormatted: "missing-name-b06d1db11321396efb70c5c483b11923",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "210",
        "ok": "206",
        "ko": "4"
    },
    "minResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "30"
    },
    "maxResponseTime": {
        "total": "3370",
        "ok": "3370",
        "ko": "100"
    },
    "meanResponseTime": {
        "total": "335",
        "ok": "340",
        "ko": "53"
    },
    "standardDeviation": {
        "total": "485",
        "ok": "488",
        "ko": "28"
    },
    "percentiles1": {
        "total": "1330",
        "ok": "1330",
        "ko": "100"
    },
    "percentiles2": {
        "total": "2330",
        "ok": "2330",
        "ko": "100"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 186,
        "percentage": 88
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 9,
        "percentage": 4
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 11,
        "percentage": 5
    },
    "group4": {
        "name": "failed",
        "count": 4,
        "percentage": 1
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
