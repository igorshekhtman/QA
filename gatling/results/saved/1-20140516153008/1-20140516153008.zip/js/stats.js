var stats = {
    type: "GROUP",
contents: {
"login-99dea78007133396a7b8ed70578ac6ae": {
        type: "GROUP",
contents: {
"login-page-024588fa3c938f335a36fec9f17624f4": {
        type: "REQUEST",
        name: "Login page",
path: "Login / Login page",
pathFormatted: "login---login-page-ec10d26222d452283ad31786b6c7417a",
stats: {
    "name": "Login page",
    "numberOfRequests": {
        "total": "60",
        "ok": "60",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "43",
        "ok": "43",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "44",
        "ok": "44",
        "ko": "-"
    },
    "percentiles1": {
        "total": "70",
        "ok": "70",
        "ko": "-"
    },
    "percentiles2": {
        "total": "170",
        "ok": "170",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 60,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"submit-login-f643596223977882be93e2205ad5e14d": {
        type: "REQUEST",
        name: "Submit login",
path: "Login / Submit login",
pathFormatted: "login---submit-login-1ecb60c3635236b2aea1825075ac3913",
stats: {
    "name": "Submit login",
    "numberOfRequests": {
        "total": "60",
        "ok": "58",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "80",
        "ok": "290",
        "ko": "80"
    },
    "maxResponseTime": {
        "total": "3260",
        "ok": "1970",
        "ko": "3260"
    },
    "meanResponseTime": {
        "total": "500",
        "ok": "459",
        "ko": "1670"
    },
    "standardDeviation": {
        "total": "488",
        "ok": "332",
        "ko": "1590"
    },
    "percentiles1": {
        "total": "1140",
        "ok": "1070",
        "ko": "3260"
    },
    "percentiles2": {
        "total": "1970",
        "ok": "1940",
        "ko": "3260"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 53,
        "percentage": 88
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 3,
        "percentage": 5
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2,
        "percentage": 3
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 3
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    }
},
name: "Login",
path: "Login",
pathFormatted: "login-99dea78007133396a7b8ed70578ac6ae",
stats: {
    "name": "Login",
    "numberOfRequests": {
        "total": "60",
        "ok": "58",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "12150",
        "ok": "12350",
        "ko": "12150"
    },
    "maxResponseTime": {
        "total": "15300",
        "ok": "14050",
        "ko": "15300"
    },
    "meanResponseTime": {
        "total": "12566",
        "ok": "12526",
        "ko": "13725"
    },
    "standardDeviation": {
        "total": "479",
        "ok": "324",
        "ko": "1575"
    },
    "percentiles1": {
        "total": "13200",
        "ok": "13150",
        "ko": "15300"
    },
    "percentiles2": {
        "total": "14050",
        "ok": "14000",
        "ko": "15300"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 58,
        "percentage": 96
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 3
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"token-459a6f79ad9b13cbcb5f692d2cc7a94d": {
        type: "GROUP",
contents: {
"token-exchange-ce37265b594ed58a9857bdf00c769ea8": {
        type: "REQUEST",
        name: "Token exchange",
path: "Token / Token exchange",
pathFormatted: "token---token-exchange-f1298f80173ae42f1d4d7533dae4b717",
stats: {
    "name": "Token exchange",
    "numberOfRequests": {
        "total": "58",
        "ok": "58",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "30",
        "ok": "30",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "6800",
        "ok": "6800",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "160",
        "ok": "160",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "880",
        "ok": "880",
        "ko": "-"
    },
    "percentiles1": {
        "total": "80",
        "ok": "80",
        "ko": "-"
    },
    "percentiles2": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 57,
        "percentage": 98
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Token",
path: "Token",
pathFormatted: "token-459a6f79ad9b13cbcb5f692d2cc7a94d",
stats: {
    "name": "Token",
    "numberOfRequests": {
        "total": "60",
        "ok": "58",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "40",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "6800",
        "ok": "6800",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "158",
        "ok": "163",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "865",
        "ok": "879",
        "ko": "0"
    },
    "percentiles1": {
        "total": "80",
        "ok": "80",
        "ko": "0"
    },
    "percentiles2": {
        "total": "90",
        "ok": "90",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 57,
        "percentage": 95
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 1
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 3
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"patient-01122a97dca927210827560cb7d76af8": {
        type: "GROUP",
contents: {
"patient-demographics-20fa1e3af35ff968fdfaff3f17f2132f": {
        type: "REQUEST",
        name: "Patient demographics",
path: "Patient / Patient demographics",
pathFormatted: "patient---patient-demographics-7381f0c739ca78ed2209e34f68b4acce",
stats: {
    "name": "Patient demographics",
    "numberOfRequests": {
        "total": "58",
        "ok": "58",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "27760",
        "ok": "27760",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9902",
        "ok": "9902",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9454",
        "ok": "9454",
        "ko": "-"
    },
    "percentiles1": {
        "total": "25520",
        "ok": "25520",
        "ko": "-"
    },
    "percentiles2": {
        "total": "27170",
        "ok": "27170",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 18,
        "percentage": 31
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 39,
        "percentage": 67
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Patient",
path: "Patient",
pathFormatted: "patient-01122a97dca927210827560cb7d76af8",
stats: {
    "name": "Patient",
    "numberOfRequests": {
        "total": "60",
        "ok": "58",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "6000",
        "ok": "6060",
        "ko": "6000"
    },
    "maxResponseTime": {
        "total": "33780",
        "ok": "33780",
        "ko": "6000"
    },
    "meanResponseTime": {
        "total": "15574",
        "ok": "15904",
        "ko": "6000"
    },
    "standardDeviation": {
        "total": "9462",
        "ok": "9453",
        "ko": "0"
    },
    "percentiles1": {
        "total": "31500",
        "ok": "31500",
        "ko": "6000"
    },
    "percentiles2": {
        "total": "33160",
        "ok": "33160",
        "ko": "6000"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 58,
        "percentage": 96
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 3
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"document-0945359809dad1fbf3dea1c95a0da951": {
        type: "GROUP",
contents: {
"document-retrieval-text-2540ae29a705cec5500c042a139829fe": {
        type: "REQUEST",
        name: "Document retrieval text",
path: "Document / Document retrieval text",
pathFormatted: "document---document-retrieval-text-e01f7dcbbf40fdfec1dd23b9433c370c",
stats: {
    "name": "Document retrieval text",
    "numberOfRequests": {
        "total": "58",
        "ok": "58",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "140",
        "ok": "140",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "27640",
        "ok": "27640",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "4427",
        "ok": "4427",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6851",
        "ok": "6851",
        "ko": "-"
    },
    "percentiles1": {
        "total": "24270",
        "ok": "24270",
        "ko": "-"
    },
    "percentiles2": {
        "total": "27550",
        "ok": "27550",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 10,
        "percentage": 17
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 8,
        "percentage": 13
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 40,
        "percentage": 68
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"document-retrieval-metadata-930bb3ede50d721fd1a8e5b90ab1f422": {
        type: "REQUEST",
        name: "Document retrieval metadata",
path: "Document / Document retrieval metadata",
pathFormatted: "document---document-retrieval-metadata-592e662b974e9b216c65b391aacfd4d5",
stats: {
    "name": "Document retrieval metadata",
    "numberOfRequests": {
        "total": "58",
        "ok": "58",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "27230",
        "ok": "27230",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1228",
        "ok": "1228",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "4857",
        "ok": "4857",
        "ko": "-"
    },
    "percentiles1": {
        "total": "900",
        "ok": "900",
        "ko": "-"
    },
    "percentiles2": {
        "total": "26580",
        "ok": "26580",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 54,
        "percentage": 93
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 2,
        "percentage": 3
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2,
        "percentage": 3
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"document-retrieval-file-a199cf6c05a32d74b4392503ab8249fa": {
        type: "REQUEST",
        name: "Document retrieval file",
path: "Document / Document retrieval file",
pathFormatted: "document---document-retrieval-file-97948b241a7ce3b43fdc9088747c6a5b",
stats: {
    "name": "Document retrieval file",
    "numberOfRequests": {
        "total": "58",
        "ok": "58",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "160",
        "ok": "160",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1810",
        "ok": "1810",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "688",
        "ok": "688",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "366",
        "ok": "366",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1310",
        "ok": "1310",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1780",
        "ok": "1780",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 38,
        "percentage": 65
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 14,
        "percentage": 24
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 6,
        "percentage": 10
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Document",
path: "Document",
pathFormatted: "document-0945359809dad1fbf3dea1c95a0da951",
stats: {
    "name": "Document",
    "numberOfRequests": {
        "total": "60",
        "ok": "58",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "6000",
        "ok": "6500",
        "ko": "6000"
    },
    "maxResponseTime": {
        "total": "36650",
        "ok": "36650",
        "ko": "6000"
    },
    "meanResponseTime": {
        "total": "12136",
        "ok": "12347",
        "ko": "6000"
    },
    "standardDeviation": {
        "total": "8061",
        "ok": "8117",
        "ko": "0"
    },
    "percentiles1": {
        "total": "34550",
        "ok": "34550",
        "ko": "6000"
    },
    "percentiles2": {
        "total": "34600",
        "ok": "34600",
        "ko": "6000"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 58,
        "percentage": 96
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 3
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    }
},
name: "Global Information",
path: "",
pathFormatted: "missing-name-b06d1db11321396efb70c5c483b11923",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "410",
        "ok": "408",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "80"
    },
    "maxResponseTime": {
        "total": "27760",
        "ok": "27760",
        "ko": "3260"
    },
    "meanResponseTime": {
        "total": "2400",
        "ok": "2404",
        "ko": "1670"
    },
    "standardDeviation": {
        "total": "5830",
        "ok": "5843",
        "ko": "1590"
    },
    "percentiles1": {
        "total": "18180",
        "ok": "18180",
        "ko": "3260"
    },
    "percentiles2": {
        "total": "27230",
        "ok": "27230",
        "ko": "3260"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 290,
        "percentage": 70
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 28,
        "percentage": 6
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 90,
        "percentage": 21
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
