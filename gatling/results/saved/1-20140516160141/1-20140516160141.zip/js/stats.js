var stats = {
    type: "GROUP",
contents: {
"login-99dea78007133396a7b8ed70578ac6ae": {
        type: "GROUP",
contents: {
"login-page-024588fa3c938f335a36fec9f17624f4": {
        type: "REQUEST",
        name: "Login page",
path: "Login / Login page",
pathFormatted: "login---login-page-ec10d26222d452283ad31786b6c7417a",
stats: {
    "name": "Login page",
    "numberOfRequests": {
        "total": "28",
        "ok": "4",
        "ko": "24"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "140",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "1020",
        "ok": "370",
        "ko": "1020"
    },
    "meanResponseTime": {
        "total": "316",
        "ok": "250",
        "ko": "327"
    },
    "standardDeviation": {
        "total": "367",
        "ok": "90",
        "ko": "394"
    },
    "percentiles1": {
        "total": "1010",
        "ok": "370",
        "ko": "1010"
    },
    "percentiles2": {
        "total": "1020",
        "ok": "370",
        "ko": "1020"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 4,
        "percentage": 14
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 24,
        "percentage": 85
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    },"submit-login-f643596223977882be93e2205ad5e14d": {
        type: "REQUEST",
        name: "Submit login",
path: "Login / Submit login",
pathFormatted: "login---submit-login-1ecb60c3635236b2aea1825075ac3913",
stats: {
    "name": "Submit login",
    "numberOfRequests": {
        "total": "18",
        "ok": "4",
        "ko": "14"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "400",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "520",
        "ok": "520",
        "ko": "50"
    },
    "meanResponseTime": {
        "total": "113",
        "ok": "470",
        "ko": "11"
    },
    "standardDeviation": {
        "total": "193",
        "ok": "44",
        "ko": "18"
    },
    "percentiles1": {
        "total": "490",
        "ok": "520",
        "ko": "50"
    },
    "percentiles2": {
        "total": "520",
        "ok": "520",
        "ko": "50"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 4,
        "percentage": 22
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 14,
        "percentage": 77
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    }
},
name: "Login",
path: "Login",
pathFormatted: "login-99dea78007133396a7b8ed70578ac6ae",
stats: {
    "name": "Login",
    "numberOfRequests": {
        "total": "18",
        "ok": "4",
        "ko": "14"
    },
    "minResponseTime": {
        "total": "12020",
        "ok": "12550",
        "ko": "12020"
    },
    "maxResponseTime": {
        "total": "12900",
        "ok": "12900",
        "ko": "12170"
    },
    "meanResponseTime": {
        "total": "12223",
        "ok": "12758",
        "ko": "12070"
    },
    "standardDeviation": {
        "total": "286",
        "ok": "88",
        "ko": "40"
    },
    "percentiles1": {
        "total": "12880",
        "ok": "12900",
        "ko": "12100"
    },
    "percentiles2": {
        "total": "12900",
        "ok": "12900",
        "ko": "12170"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 4,
        "percentage": 22
    },
    "group4": {
        "name": "failed",
        "count": 14,
        "percentage": 77
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"token-459a6f79ad9b13cbcb5f692d2cc7a94d": {
        type: "GROUP",
contents: {
"token-exchange-ce37265b594ed58a9857bdf00c769ea8": {
        type: "REQUEST",
        name: "Token exchange",
path: "Token / Token exchange",
pathFormatted: "token---token-exchange-f1298f80173ae42f1d4d7533dae4b717",
stats: {
    "name": "Token exchange",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "73",
        "ok": "73",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    },
    "percentiles1": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "percentiles2": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 4,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Token",
path: "Token",
pathFormatted: "token-459a6f79ad9b13cbcb5f692d2cc7a94d",
stats: {
    "name": "Token",
    "numberOfRequests": {
        "total": "18",
        "ok": "4",
        "ko": "14"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "60",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "150",
        "ok": "150",
        "ko": "10"
    },
    "meanResponseTime": {
        "total": "23",
        "ok": "95",
        "ko": "3"
    },
    "standardDeviation": {
        "total": "42",
        "ok": "34",
        "ko": "4"
    },
    "percentiles1": {
        "total": "90",
        "ok": "150",
        "ko": "10"
    },
    "percentiles2": {
        "total": "150",
        "ok": "150",
        "ko": "10"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 4,
        "percentage": 22
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 14,
        "percentage": 77
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"patient-01122a97dca927210827560cb7d76af8": {
        type: "GROUP",
contents: {
"patient-demographics-20fa1e3af35ff968fdfaff3f17f2132f": {
        type: "REQUEST",
        name: "Patient demographics",
path: "Patient / Patient demographics",
pathFormatted: "patient---patient-demographics-7381f0c739ca78ed2209e34f68b4acce",
stats: {
    "name": "Patient demographics",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "230",
        "ok": "230",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23610",
        "ok": "23610",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "14820",
        "ok": "14820",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "9232",
        "ok": "9232",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23610",
        "ok": "23610",
        "ko": "-"
    },
    "percentiles2": {
        "total": "23610",
        "ok": "23610",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 25
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 3,
        "percentage": 75
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Patient",
path: "Patient",
pathFormatted: "patient-01122a97dca927210827560cb7d76af8",
stats: {
    "name": "Patient",
    "numberOfRequests": {
        "total": "18",
        "ok": "4",
        "ko": "14"
    },
    "minResponseTime": {
        "total": "5960",
        "ok": "6240",
        "ko": "5960"
    },
    "maxResponseTime": {
        "total": "29620",
        "ok": "29620",
        "ko": "6070"
    },
    "meanResponseTime": {
        "total": "9294",
        "ok": "20805",
        "ko": "6005"
    },
    "standardDeviation": {
        "total": "7531",
        "ok": "9213",
        "ko": "33"
    },
    "percentiles1": {
        "total": "27750",
        "ok": "29620",
        "ko": "6070"
    },
    "percentiles2": {
        "total": "29620",
        "ok": "29620",
        "ko": "6070"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 4,
        "percentage": 22
    },
    "group4": {
        "name": "failed",
        "count": 14,
        "percentage": 77
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"document-0945359809dad1fbf3dea1c95a0da951": {
        type: "GROUP",
contents: {
"document-retrieval-text-2540ae29a705cec5500c042a139829fe": {
        type: "REQUEST",
        name: "Document retrieval text",
path: "Document / Document retrieval text",
pathFormatted: "document---document-retrieval-text-e01f7dcbbf40fdfec1dd23b9433c370c",
stats: {
    "name": "Document retrieval text",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "710",
        "ok": "710",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "24430",
        "ok": "24430",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7078",
        "ok": "7078",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "10027",
        "ok": "10027",
        "ko": "-"
    },
    "percentiles1": {
        "total": "24430",
        "ok": "24430",
        "ko": "-"
    },
    "percentiles2": {
        "total": "24430",
        "ok": "24430",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 25
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 3,
        "percentage": 75
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"document-retrieval-metadata-930bb3ede50d721fd1a8e5b90ab1f422": {
        type: "REQUEST",
        name: "Document retrieval metadata",
path: "Document / Document retrieval metadata",
pathFormatted: "document---document-retrieval-metadata-592e662b974e9b216c65b391aacfd4d5",
stats: {
    "name": "Document retrieval metadata",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "50",
        "ok": "50",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1500",
        "ok": "1500",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "450",
        "ok": "450",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "609",
        "ok": "609",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1500",
        "ok": "1500",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1500",
        "ok": "1500",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 3,
        "percentage": 75
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 25
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"document-retrieval-file-a199cf6c05a32d74b4392503ab8249fa": {
        type: "REQUEST",
        name: "Document retrieval file",
path: "Document / Document retrieval file",
pathFormatted: "document---document-retrieval-file-97948b241a7ce3b43fdc9088747c6a5b",
stats: {
    "name": "Document retrieval file",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "260",
        "ok": "260",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "800",
        "ok": "800",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "513",
        "ok": "513",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "207",
        "ok": "207",
        "ko": "-"
    },
    "percentiles1": {
        "total": "800",
        "ok": "800",
        "ko": "-"
    },
    "percentiles2": {
        "total": "800",
        "ok": "800",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 3,
        "percentage": 75
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 25
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Document",
path: "Document",
pathFormatted: "document-0945359809dad1fbf3dea1c95a0da951",
stats: {
    "name": "Document",
    "numberOfRequests": {
        "total": "18",
        "ok": "4",
        "ko": "14"
    },
    "minResponseTime": {
        "total": "5940",
        "ok": "7000",
        "ko": "5940"
    },
    "maxResponseTime": {
        "total": "31000",
        "ok": "31000",
        "ko": "6050"
    },
    "meanResponseTime": {
        "total": "7786",
        "ok": "14038",
        "ko": "6000"
    },
    "standardDeviation": {
        "total": "5722",
        "ok": "9853",
        "ko": "30"
    },
    "percentiles1": {
        "total": "10050",
        "ok": "31000",
        "ko": "6050"
    },
    "percentiles2": {
        "total": "31000",
        "ok": "31000",
        "ko": "6050"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 4,
        "percentage": 22
    },
    "group4": {
        "name": "failed",
        "count": 14,
        "percentage": 77
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    }
},
name: "Global Information",
path: "",
pathFormatted: "missing-name-b06d1db11321396efb70c5c483b11923",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "66",
        "ok": "28",
        "ko": "38"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "50",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "24430",
        "ok": "24430",
        "ko": "1020"
    },
    "meanResponseTime": {
        "total": "1555",
        "ok": "3379",
        "ko": "211"
    },
    "standardDeviation": {
        "total": "5035",
        "ok": "7336",
        "ko": "348"
    },
    "percentiles1": {
        "total": "13600",
        "ok": "23610",
        "ko": "990"
    },
    "percentiles2": {
        "total": "23610",
        "ok": "24430",
        "ko": "1020"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 20,
        "percentage": 30
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 1
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 7,
        "percentage": 10
    },
    "group4": {
        "name": "failed",
        "count": 38,
        "percentage": 57
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
