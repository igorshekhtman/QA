var stats = {
    type: "GROUP",
contents: {
"login-99dea78007133396a7b8ed70578ac6ae": {
        type: "GROUP",
contents: {
"login-page-024588fa3c938f335a36fec9f17624f4": {
        type: "REQUEST",
        name: "Login page",
path: "Login / Login page",
pathFormatted: "login---login-page-ec10d26222d452283ad31786b6c7417a",
stats: {
    "name": "Login page",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "31",
        "ok": "31",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles1": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "percentiles2": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 30,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"submit-login-f643596223977882be93e2205ad5e14d": {
        type: "REQUEST",
        name: "Submit login",
path: "Login / Submit login",
pathFormatted: "login---submit-login-1ecb60c3635236b2aea1825075ac3913",
stats: {
    "name": "Submit login",
    "numberOfRequests": {
        "total": "30",
        "ok": "28",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "80",
        "ok": "310",
        "ko": "80"
    },
    "maxResponseTime": {
        "total": "1890",
        "ok": "460",
        "ko": "1890"
    },
    "meanResponseTime": {
        "total": "405",
        "ok": "364",
        "ko": "985"
    },
    "standardDeviation": {
        "total": "283",
        "ok": "37",
        "ko": "905"
    },
    "percentiles1": {
        "total": "460",
        "ok": "440",
        "ko": "1890"
    },
    "percentiles2": {
        "total": "1890",
        "ok": "460",
        "ko": "1890"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 28,
        "percentage": 93
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    }
},
name: "Login",
path: "Login",
pathFormatted: "login-99dea78007133396a7b8ed70578ac6ae",
stats: {
    "name": "Login",
    "numberOfRequests": {
        "total": "30",
        "ok": "28",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "12150",
        "ok": "12350",
        "ko": "12150"
    },
    "maxResponseTime": {
        "total": "13950",
        "ok": "12600",
        "ko": "13950"
    },
    "meanResponseTime": {
        "total": "12465",
        "ok": "12423",
        "ko": "13050"
    },
    "standardDeviation": {
        "total": "284",
        "ok": "89",
        "ko": "900"
    },
    "percentiles1": {
        "total": "12600",
        "ok": "12500",
        "ko": "13950"
    },
    "percentiles2": {
        "total": "13950",
        "ok": "12600",
        "ko": "13950"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 28,
        "percentage": 93
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"token-459a6f79ad9b13cbcb5f692d2cc7a94d": {
        type: "GROUP",
contents: {
"token-exchange-ce37265b594ed58a9857bdf00c769ea8": {
        type: "REQUEST",
        name: "Token exchange",
path: "Token / Token exchange",
pathFormatted: "token---token-exchange-f1298f80173ae42f1d4d7533dae4b717",
stats: {
    "name": "Token exchange",
    "numberOfRequests": {
        "total": "28",
        "ok": "28",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "30",
        "ok": "30",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "45",
        "ok": "45",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles1": {
        "total": "80",
        "ok": "80",
        "ko": "-"
    },
    "percentiles2": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 28,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Token",
path: "Token",
pathFormatted: "token-459a6f79ad9b13cbcb5f692d2cc7a94d",
stats: {
    "name": "Token",
    "numberOfRequests": {
        "total": "30",
        "ok": "28",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "40",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "120",
        "ok": "120",
        "ko": "0"
    },
    "meanResponseTime": {
        "total": "47",
        "ok": "51",
        "ko": "0"
    },
    "standardDeviation": {
        "total": "25",
        "ok": "21",
        "ko": "0"
    },
    "percentiles1": {
        "total": "110",
        "ok": "110",
        "ko": "0"
    },
    "percentiles2": {
        "total": "120",
        "ok": "120",
        "ko": "0"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 28,
        "percentage": 93
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 6
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"patient-01122a97dca927210827560cb7d76af8": {
        type: "GROUP",
contents: {
"patient-demographics-20fa1e3af35ff968fdfaff3f17f2132f": {
        type: "REQUEST",
        name: "Patient demographics",
path: "Patient / Patient demographics",
pathFormatted: "patient---patient-demographics-7381f0c739ca78ed2209e34f68b4acce",
stats: {
    "name": "Patient demographics",
    "numberOfRequests": {
        "total": "28",
        "ok": "0",
        "ko": "28"
    },
    "minResponseTime": {
        "total": "60010",
        "ok": "-",
        "ko": "60010"
    },
    "maxResponseTime": {
        "total": "60050",
        "ok": "-",
        "ko": "60050"
    },
    "meanResponseTime": {
        "total": "60020",
        "ok": "-",
        "ko": "60020"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles1": {
        "total": "60030",
        "ok": "-",
        "ko": "60030"
    },
    "percentiles2": {
        "total": "60050",
        "ok": "-",
        "ko": "60050"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 28,
        "percentage": 100
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    }
}
    }
},
name: "Patient",
path: "Patient",
pathFormatted: "patient-01122a97dca927210827560cb7d76af8",
stats: {
    "name": "Patient",
    "numberOfRequests": {
        "total": "30",
        "ok": "0",
        "ko": "30"
    },
    "minResponseTime": {
        "total": "6000",
        "ok": "-",
        "ko": "6000"
    },
    "maxResponseTime": {
        "total": "66060",
        "ok": "-",
        "ko": "66060"
    },
    "meanResponseTime": {
        "total": "62010",
        "ok": "-",
        "ko": "62010"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    },
    "percentiles1": {
        "total": "66060",
        "ok": "-",
        "ko": "66060"
    },
    "percentiles2": {
        "total": "66060",
        "ok": "-",
        "ko": "66060"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 30,
        "percentage": 100
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    }
}

    },"document-0945359809dad1fbf3dea1c95a0da951": {
        type: "GROUP",
contents: {
"document-retrieval-text-2540ae29a705cec5500c042a139829fe": {
        type: "REQUEST",
        name: "Document retrieval text",
path: "Document / Document retrieval text",
pathFormatted: "document---document-retrieval-text-e01f7dcbbf40fdfec1dd23b9433c370c",
stats: {
    "name": "Document retrieval text",
    "numberOfRequests": {
        "total": "28",
        "ok": "0",
        "ko": "28"
    },
    "minResponseTime": {
        "total": "30",
        "ok": "-",
        "ko": "30"
    },
    "maxResponseTime": {
        "total": "1710",
        "ok": "-",
        "ko": "1710"
    },
    "meanResponseTime": {
        "total": "92",
        "ok": "-",
        "ko": "92"
    },
    "standardDeviation": {
        "total": "311",
        "ok": "-",
        "ko": "311"
    },
    "percentiles1": {
        "total": "50",
        "ok": "-",
        "ko": "50"
    },
    "percentiles2": {
        "total": "1710",
        "ok": "-",
        "ko": "1710"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 28,
        "percentage": 100
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    }
}
    },"document-retrieval-metadata-930bb3ede50d721fd1a8e5b90ab1f422": {
        type: "REQUEST",
        name: "Document retrieval metadata",
path: "Document / Document retrieval metadata",
pathFormatted: "document---document-retrieval-metadata-592e662b974e9b216c65b391aacfd4d5",
stats: {
    "name": "Document retrieval metadata",
    "numberOfRequests": {
        "total": "28",
        "ok": "0",
        "ko": "28"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "-",
        "ko": "10"
    },
    "maxResponseTime": {
        "total": "40",
        "ok": "-",
        "ko": "40"
    },
    "meanResponseTime": {
        "total": "23",
        "ok": "-",
        "ko": "23"
    },
    "standardDeviation": {
        "total": "7",
        "ok": "-",
        "ko": "7"
    },
    "percentiles1": {
        "total": "40",
        "ok": "-",
        "ko": "40"
    },
    "percentiles2": {
        "total": "40",
        "ok": "-",
        "ko": "40"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 28,
        "percentage": 100
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    }
}
    },"document-retrieval-file-a199cf6c05a32d74b4392503ab8249fa": {
        type: "REQUEST",
        name: "Document retrieval file",
path: "Document / Document retrieval file",
pathFormatted: "document---document-retrieval-file-97948b241a7ce3b43fdc9088747c6a5b",
stats: {
    "name": "Document retrieval file",
    "numberOfRequests": {
        "total": "28",
        "ok": "0",
        "ko": "28"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "-",
        "ko": "10"
    },
    "maxResponseTime": {
        "total": "20",
        "ok": "-",
        "ko": "20"
    },
    "meanResponseTime": {
        "total": "16",
        "ok": "-",
        "ko": "16"
    },
    "standardDeviation": {
        "total": "6",
        "ok": "-",
        "ko": "6"
    },
    "percentiles1": {
        "total": "20",
        "ok": "-",
        "ko": "20"
    },
    "percentiles2": {
        "total": "20",
        "ok": "-",
        "ko": "20"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 28,
        "percentage": 100
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    }
}
    }
},
name: "Document",
path: "Document",
pathFormatted: "document-0945359809dad1fbf3dea1c95a0da951",
stats: {
    "name": "Document",
    "numberOfRequests": {
        "total": "30",
        "ok": "0",
        "ko": "30"
    },
    "minResponseTime": {
        "total": "6000",
        "ok": "-",
        "ko": "6000"
    },
    "maxResponseTime": {
        "total": "7750",
        "ok": "-",
        "ko": "7750"
    },
    "meanResponseTime": {
        "total": "6125",
        "ok": "-",
        "ko": "6125"
    },
    "standardDeviation": {
        "total": "303",
        "ok": "-",
        "ko": "303"
    },
    "percentiles1": {
        "total": "6100",
        "ok": "-",
        "ko": "6100"
    },
    "percentiles2": {
        "total": "7750",
        "ok": "-",
        "ko": "7750"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 30,
        "percentage": 100
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "-",
        "ko": "0"
    }
}

    }
},
name: "Global Information",
path: "",
pathFormatted: "missing-name-b06d1db11321396efb70c5c483b11923",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "200",
        "ok": "86",
        "ko": "114"
    },
    "minResponseTime": {
        "total": "10",
        "ok": "20",
        "ko": "10"
    },
    "maxResponseTime": {
        "total": "60050",
        "ok": "460",
        "ko": "60050"
    },
    "meanResponseTime": {
        "total": "8493",
        "ok": "144",
        "ko": "14791"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "155",
        "ko": "0"
    },
    "percentiles1": {
        "total": "60020",
        "ok": "400",
        "ko": "60020"
    },
    "percentiles2": {
        "total": "60030",
        "ok": "440",
        "ko": "60030"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 86,
        "percentage": 43
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 114,
        "percentage": 57
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
