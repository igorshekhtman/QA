var stats = {
    type: "GROUP",
contents: {
"login-99dea78007133396a7b8ed70578ac6ae": {
        type: "GROUP",
contents: {
"login-page-024588fa3c938f335a36fec9f17624f4": {
        type: "REQUEST",
        name: "Login page",
path: "Login / Login page",
pathFormatted: "login---login-page-ec10d26222d452283ad31786b6c7417a",
stats: {
    "name": "Login page",
    "numberOfRequests": {
        "total": "31",
        "ok": "31",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "29",
        "ok": "29",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles1": {
        "total": "30",
        "ok": "30",
        "ko": "-"
    },
    "percentiles2": {
        "total": "90",
        "ok": "90",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 31,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    },"submit-login-f643596223977882be93e2205ad5e14d": {
        type: "REQUEST",
        name: "Submit login",
path: "Login / Submit login",
pathFormatted: "login---submit-login-1ecb60c3635236b2aea1825075ac3913",
stats: {
    "name": "Submit login",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "290",
        "ok": "290",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "490",
        "ok": "490",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "342",
        "ok": "342",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "percentiles1": {
        "total": "400",
        "ok": "400",
        "ko": "-"
    },
    "percentiles2": {
        "total": "490",
        "ok": "490",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 30,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Login",
path: "Login",
pathFormatted: "login-99dea78007133396a7b8ed70578ac6ae",
stats: {
    "name": "Login",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "12350",
        "ok": "12350",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "12550",
        "ok": "12550",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "12399",
        "ok": "12399",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "percentiles1": {
        "total": "12470",
        "ok": "12470",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12550",
        "ok": "12550",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 30,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}

    },"token-459a6f79ad9b13cbcb5f692d2cc7a94d": {
        type: "GROUP",
contents: {
"token-exchange-ce37265b594ed58a9857bdf00c769ea8": {
        type: "REQUEST",
        name: "Token exchange",
path: "Token / Token exchange",
pathFormatted: "token---token-exchange-f1298f80173ae42f1d4d7533dae4b717",
stats: {
    "name": "Token exchange",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "30",
        "ok": "30",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "56",
        "ok": "56",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "33",
        "ok": "33",
        "ko": "-"
    },
    "percentiles1": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "percentiles2": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 30,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}
    }
},
name: "Token",
path: "Token",
pathFormatted: "token-459a6f79ad9b13cbcb5f692d2cc7a94d",
stats: {
    "name": "Token",
    "numberOfRequests": {
        "total": "30",
        "ok": "30",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "36",
        "ok": "36",
        "ko": "-"
    },
    "percentiles1": {
        "total": "120",
        "ok": "120",
        "ko": "-"
    },
    "percentiles2": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 30,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    }
}

    },"patient-01122a97dca927210827560cb7d76af8": {
        type: "GROUP",
contents: {
"patient-demographics-20fa1e3af35ff968fdfaff3f17f2132f": {
        type: "REQUEST",
        name: "Patient demographics",
path: "Patient / Patient demographics",
pathFormatted: "patient---patient-demographics-7381f0c739ca78ed2209e34f68b4acce",
stats: {
    "name": "Patient demographics",
    "numberOfRequests": {
        "total": "24",
        "ok": "7",
        "ko": "17"
    },
    "minResponseTime": {
        "total": "130",
        "ok": "130",
        "ko": "60010"
    },
    "maxResponseTime": {
        "total": "60030",
        "ok": "32290",
        "ko": "60030"
    },
    "meanResponseTime": {
        "total": "45971",
        "ok": "11856",
        "ko": "60018"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "13368",
        "ko": "0"
    },
    "percentiles1": {
        "total": "60020",
        "ok": "32290",
        "ko": "60020"
    },
    "percentiles2": {
        "total": "60030",
        "ok": "32290",
        "ko": "60030"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 2,
        "percentage": 8
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 5,
        "percentage": 20
    },
    "group4": {
        "name": "failed",
        "count": 17,
        "percentage": 70
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    }
},
name: "Patient",
path: "Patient",
pathFormatted: "patient-01122a97dca927210827560cb7d76af8",
stats: {
    "name": "Patient",
    "numberOfRequests": {
        "total": "23",
        "ok": "7",
        "ko": "16"
    },
    "minResponseTime": {
        "total": "6110",
        "ok": "6110",
        "ko": "66010"
    },
    "maxResponseTime": {
        "total": "66060",
        "ok": "38280",
        "ko": "66060"
    },
    "meanResponseTime": {
        "total": "51357",
        "ok": "17846",
        "ko": "66018"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "13355",
        "ko": "0"
    },
    "percentiles1": {
        "total": "66050",
        "ok": "38280",
        "ko": "66050"
    },
    "percentiles2": {
        "total": "66060",
        "ok": "38280",
        "ko": "66060"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 7,
        "percentage": 30
    },
    "group4": {
        "name": "failed",
        "count": 16,
        "percentage": 69
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    },"document-0945359809dad1fbf3dea1c95a0da951": {
        type: "GROUP",
contents: {
"document-retrieval-text-2540ae29a705cec5500c042a139829fe": {
        type: "REQUEST",
        name: "Document retrieval text",
path: "Document / Document retrieval text",
pathFormatted: "document---document-retrieval-text-e01f7dcbbf40fdfec1dd23b9433c370c",
stats: {
    "name": "Document retrieval text",
    "numberOfRequests": {
        "total": "17",
        "ok": "4",
        "ko": "13"
    },
    "minResponseTime": {
        "total": "240",
        "ok": "240",
        "ko": "360"
    },
    "maxResponseTime": {
        "total": "60020",
        "ok": "3660",
        "ko": "60020"
    },
    "meanResponseTime": {
        "total": "42873",
        "ok": "2070",
        "ko": "55428"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "1474",
        "ko": "0"
    },
    "percentiles1": {
        "total": "60020",
        "ok": "3660",
        "ko": "60020"
    },
    "percentiles2": {
        "total": "60020",
        "ok": "3660",
        "ko": "60020"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 5
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 5
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 2,
        "percentage": 11
    },
    "group4": {
        "name": "failed",
        "count": 13,
        "percentage": 76
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    },"document-retrieval-metadata-930bb3ede50d721fd1a8e5b90ab1f422": {
        type: "REQUEST",
        name: "Document retrieval metadata",
path: "Document / Document retrieval metadata",
pathFormatted: "document---document-retrieval-metadata-592e662b974e9b216c65b391aacfd4d5",
stats: {
    "name": "Document retrieval metadata",
    "numberOfRequests": {
        "total": "12",
        "ok": "5",
        "ko": "7"
    },
    "minResponseTime": {
        "total": "100",
        "ok": "100",
        "ko": "60010"
    },
    "maxResponseTime": {
        "total": "60050",
        "ok": "240",
        "ko": "60050"
    },
    "meanResponseTime": {
        "total": "35076",
        "ok": "150",
        "ko": "60023"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "56",
        "ko": "0"
    },
    "percentiles1": {
        "total": "60030",
        "ok": "240",
        "ko": "60050"
    },
    "percentiles2": {
        "total": "60050",
        "ok": "240",
        "ko": "60050"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 5,
        "percentage": 41
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 7,
        "percentage": 58
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    },"document-retrieval-file-a199cf6c05a32d74b4392503ab8249fa": {
        type: "REQUEST",
        name: "Document retrieval file",
path: "Document / Document retrieval file",
pathFormatted: "document---document-retrieval-file-97948b241a7ce3b43fdc9088747c6a5b",
stats: {
    "name": "Document retrieval file",
    "numberOfRequests": {
        "total": "7",
        "ok": "5",
        "ko": "2"
    },
    "minResponseTime": {
        "total": "150",
        "ok": "150",
        "ko": "60010"
    },
    "maxResponseTime": {
        "total": "60020",
        "ok": "2060",
        "ko": "60020"
    },
    "meanResponseTime": {
        "total": "17597",
        "ok": "630",
        "ko": "60015"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "720",
        "ko": "0"
    },
    "percentiles1": {
        "total": "60020",
        "ok": "2060",
        "ko": "60020"
    },
    "percentiles2": {
        "total": "60020",
        "ok": "2060",
        "ko": "60020"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 4,
        "percentage": 57
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 14
    },
    "group4": {
        "name": "failed",
        "count": 2,
        "percentage": 28
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}
    }
},
name: "Document",
path: "Document",
pathFormatted: "document-0945359809dad1fbf3dea1c95a0da951",
stats: {
    "name": "Document",
    "numberOfRequests": {
        "total": "7",
        "ok": "4",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "6500",
        "ok": "6500",
        "ko": "6900"
    },
    "maxResponseTime": {
        "total": "186050",
        "ok": "9950",
        "ko": "186050"
    },
    "meanResponseTime": {
        "total": "59229",
        "ok": "8900",
        "ko": "126333"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "1408",
        "ko": "0"
    },
    "percentiles1": {
        "total": "186050",
        "ok": "9950",
        "ko": "186050"
    },
    "percentiles2": {
        "total": "186050",
        "ok": "9950",
        "ko": "186050"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 4,
        "percentage": 57
    },
    "group4": {
        "name": "failed",
        "count": 3,
        "percentage": 42
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

    }
},
name: "Global Information",
path: "",
pathFormatted: "missing-name-b06d1db11321396efb70c5c483b11923",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "151",
        "ok": "112",
        "ko": "39"
    },
    "minResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "360"
    },
    "maxResponseTime": {
        "total": "60050",
        "ok": "32290",
        "ko": "60050"
    },
    "meanResponseTime": {
        "total": "15822",
        "ok": "964",
        "ko": "58489"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "4397",
        "ko": "0"
    },
    "percentiles1": {
        "total": "60020",
        "ok": "2060",
        "ko": "60030"
    },
    "percentiles2": {
        "total": "60030",
        "ok": "32000",
        "ko": "60050"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 103,
        "percentage": 68
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 1,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 8,
        "percentage": 5
    },
    "group4": {
        "name": "failed",
        "count": 39,
        "percentage": 25
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
